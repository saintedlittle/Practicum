# Practicum
My projects in Yandex practicum 

### ЕСЛИ ИЗОБРАЖЕНИЯ НЕ ДОБАВИЛИСЬ, ПОСМОТРИТЕ [GITHUB](https://github.com/saintedlittle/Practicum) !!!